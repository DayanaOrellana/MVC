<!DOCTYPE html>
<html>
<head>
    <title>Lista de Alumnos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <?= view('_navbar') ?>

    <div class="container">
    <h4>Alumnos</h4>
    <a class="btn waves-effect" href="<?= site_url('alumnos/create') ?>">➕ Nuevo Alumno</a>
    <table class="striped highlight responsive-table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Dirección</th>
            <th>Móvil</th>
            <th>Email</th>
            <th>Asignar</th>
            <th>Ver cursos</th>
            <th>Inactivo</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($alumnos as $alumno): ?>
        <tr data-id="<?= $alumno['alumno'] ?>">
            <td><?= $alumno['alumno'] ?></td>
            <td><?= esc($alumno['nombre']) ?></td>
            <td><?= esc($alumno['apellido']) ?></td>
            <td><?= esc($alumno['direccion']) ?></td>
            <td><?= esc($alumno['movil']) ?></td>
            <td><?= esc($alumno['email']) ?></td>
            <td>
              <a href="#modal-asignar" class="modal-trigger asignar-btn" data-id="<?= $alumno['alumno'] ?>" title="Asignar cursos">
                <i class="material-icons asignar-icon">playlist_add</i>
              </a>
            </td>
            <td>
              <a href="#modal-ver" class="modal-trigger ver-btn" data-id="<?= $alumno['alumno'] ?>" title="Ver cursos asignados">
                <i class="material-icons">visibility</i>
              </a>
            </td>
            <td><?= $alumno['inactivo'] ? 'Sí' : 'No' ?></td>
            <td>
                <a class="btn-small blue" href="<?= site_url('alumnos/edit/' . $alumno['alumno']) ?>">✏️ Editar</a>
                <a class="btn-small red" href="<?= site_url('alumnos/delete/' . $alumno['alumno']) ?>" onclick="return confirm('¿Seguro que quieres eliminar?')">🗑️ Eliminar</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>

    <!-- Modal Asignar -->
    <div id="modal-asignar" class="modal">
      <div class="modal-content">
        <h5>Asignar cursos</h5>
        <form id="form-asignar" method="post">
          <div id="lista-cursos" class="section">
            Cargando cursos...
          </div>
          <div class="section right-align">
            <button class="btn" type="submit">Guardar</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Modal Ver -->
    <div id="modal-ver" class="modal">
      <div class="modal-content">
        <h5>Cursos asignados</h5>
        <ul id="lista-asignados" class="collection"></ul>
      </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        const modals = document.querySelectorAll('.modal');
        M.Modal.init(modals);

        // Pintar iconos según conteo
        document.querySelectorAll('tr[data-id]').forEach(tr => {
          const id = tr.getAttribute('data-id');
          fetch('<?= site_url('alumnos') ?>/'+id+'/count')
            .then(r => r.json()).then(({count}) => {
              const icon = tr.querySelector('.asignar-icon');
              if (count > 0) {
                icon.classList.add('teal-text', 'text-darken-2');
              } else {
                icon.classList.remove('teal-text', 'text-darken-2');
              }
            });
        });

        // Abrir modal asignar
        let currentAlumno = null;
        document.querySelectorAll('.asignar-btn').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            currentAlumno = e.currentTarget.getAttribute('data-id');
            // Cargar cursos
            const cont = document.getElementById('lista-cursos');
            cont.innerHTML = 'Cargando...';
            const cursos = await fetch('<?= site_url('cursos/json') ?>').then(r=>r.json());
            const asignados = await fetch('<?= site_url('alumnos') ?>/'+currentAlumno+'/asignados').then(r=>r.json());
            const setAsign = new Set(asignados.map(a => String(a.curso)));
            const html = cursos.map(c => `
              <label>
                <input type="checkbox" name="cursos[]" value="${c.curso}" ${setAsign.has(String(c.curso)) ? 'checked':''} />
                <span>${c.nombre} — ${c.profesor}</span>
              </label><br/>`).join('');
            cont.innerHTML = html || '<em>No hay cursos activos.</em>';

            // Set action
            document.getElementById('form-asignar').setAttribute('action', '<?= site_url('alumnos') ?>/'+currentAlumno+'/guardar-cursos');
          });
        });

        // Abrir modal ver
        document.querySelectorAll('.ver-btn').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const id = e.currentTarget.getAttribute('data-id');
            const list = document.getElementById('lista-asignados');
            list.innerHTML = '<li class="collection-item">Cargando...</li>';
            const datos = await fetch('<?= site_url('alumnos') ?>/'+id+'/asignados').then(r=>r.json());
            if (datos.length === 0) {
              list.innerHTML = '<li class="collection-item"><em>Sin cursos asignados</em></li>';
            } else {
              list.innerHTML = datos.map(d => `<li class="collection-item">${d.nombre} — ${d.profesor}</li>`).join('');
            }
          });
        });
      });
    </script>
</body>
</html>
