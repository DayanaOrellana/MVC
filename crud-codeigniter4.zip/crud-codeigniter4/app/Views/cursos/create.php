<!DOCTYPE html>
<html>
<head>
  <title>Crear Curso</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet">
</head>
<body class="container">
  <h4>Nuevo Curso</h4>
  <form method="post" action="<?= site_url('cursos/store') ?>">
    <div class="input-field">
      <input type="text" name="nombre" id="nombre" required>
      <label for="nombre">Nombre</label>
    </div>
    <div class="input-field">
      <input type="text" name="profesor" id="profesor" required>
      <label for="profesor">Profesor</label>
    </div>
    <label>
      <input type="checkbox" name="inactivo" />
      <span>Inactivo</span>
    </label>
    <div class="section">
      <button class="btn waves-effect">Guardar</button>
      <a href="<?= site_url('cursos') ?>" class="btn grey">Cancelar</a>
    </div>
  </form>
</body>
</html>
