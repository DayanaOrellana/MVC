<!DOCTYPE html>
<html>
<head>
  <title>Editar Curso</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet">
</head>
<body class="container">
  <h4>Editar Curso</h4>
  <form method="post" action="<?= site_url('cursos/update/' . $curso['curso']) ?>">
    <div class="input-field">
      <input type="text" name="nombre" id="nombre" value="<?= esc($curso['nombre']) ?>" required>
      <label for="nombre" class="active">Nombre</label>
    </div>
    <div class="input-field">
      <input type="text" name="profesor" id="profesor" value="<?= esc($curso['profesor']) ?>" required>
      <label for="profesor" class="active">Profesor</label>
    </div>
    <label>
      <input type="checkbox" name="inactivo" <?= $curso['inactivo'] ? 'checked' : '' ?> />
      <span>Inactivo</span>
    </label>
    <div class="section">
      <button class="btn waves-effect">Actualizar</button>
      <a href="<?= site_url('cursos') ?>" class="btn grey">Cancelar</a>
    </div>
  </form>
</body>
</html>
